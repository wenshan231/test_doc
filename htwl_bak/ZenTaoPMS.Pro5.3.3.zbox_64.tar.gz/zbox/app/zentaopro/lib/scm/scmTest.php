<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPol3uzwEATWHxtLs/JuSlmuxDYnQDZJ4vCwblQPo0kKauJRWynsjsJSC5D+RgQtrQVjDkwUx
Iiqo3veIMhj+1TtFj9Od/uBMZbdwoHtG05G1p/usioogFqfZz17qBQSQ6kuKEXKiyEMKDuc6OyHj
Tp3YCG381TGD4Evwck8arWXoyT2LQ6ePHKzsktzM+iMO1ruac3QBgz92JWMEXcMYCqm/tW9a9Jrh
PMFnaBZpyYyxaaA/D2/iexVZaSdCv8JAerfvEQdokquf/25k7rxfqh7B6/LQcXD1DUCmJR4Hct4E
A+7DSjmkMkscLrh4ZHn/RSRla7eWVHzKfeNeuDYmWXjDSPvdbJOomMq6hLzjc/t6GI2XToDpqZ5p
Qe80Z9mchcjuMvzqekEmnvAlVnygknQIg70/hgnn0V7wwEu/trBhXYKXRYL55oMW8NELdx82t+ab
kZONjLNP+vB+u956I5OPFSMQiPkU4sFBZS6cGVyfTlzW08fHnchzay0Y3a4TN78DYxWHBHby7FxD
wzD9JmBJnSk7B2/7fZSnbEYVDBie3q0ouUP45uZfzTzmLd5niZITxllcGXzQXY1IL5k0imwBDONp
aseN+lre9WfpkwnQVH6/WtrC1oDaA08GPsnvxy8+wyn3IfmkNStz7mT2cLfXkLfSqdtcVOJb0Fuo
o2wnmaTOMmWNBnhFaSgcODK8DhXYdA36j5exps8l/WFPo6hPlLlXv6BDM2g04qzgt/1CSqdbZV31
8j7t9G8pD2KOR6Zb4QmfLEuN62PNJHdHSM1wEh4XQGo5k53errKXIPbHpOKKmsesRfGL04x9C+Zy
3BJt16SjInPOS6TCLtwXFQzLdlrR7zoOBUXYLU0/MuE4sw22bFFGT7PZM4qJTQgKhifpQ+QCjGcB
LvrnpwFBmw5muV5m5b1O4RCl3Ym4TeZDWvADRfAAKjC5m1Yb1F+nah1tzWKHDFHDq9oI5qMFjNI+
EpYPMlDYW580yJungyuYxsupmDi2ZHK8uChkWTM16a3glsOY4AJI9UhudoGAyaONhYtN3jeze3hp
XsNvtmvtR3rJkhts5HVRerNS45qFLUASVX4wDL6mOU0YD0WKNVXqXb81oc4/tQAwtukH+/lMlV3+
LlsOSowQ+ZV0c169R/WjyX6QhTnbruNmilrPqBwX6ekj