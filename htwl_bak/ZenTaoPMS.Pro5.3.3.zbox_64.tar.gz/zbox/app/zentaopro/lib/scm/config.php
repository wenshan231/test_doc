<?php
$config = new stdclass();
$config->debug = false;
